# grafik-chart.js
Tutorial Membuat Grafik Chart.js www.malasngoding.com

Tutorial https://www.malasngoding.com/membuat-grafik-dengan-chart-js/
<br/>
Demo https://malasngoding.github.io/grafik-chart.js/
