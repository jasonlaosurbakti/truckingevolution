<ul>
	<li><a href="?page=Laporan-User">Laporan Data User</a></li>
	<li><a href="?page=Laporan-Supplier">Laporan Data Supplier</a></li>
	<li><a href="?page=Laporan-Kategori">Laporan Data Kategori</a></li>
	<li><a href="?page=Laporan-Menu">Laporan Data Stock Code</a></li>
	<li><a href="?page=Laporan-Menu-by-Kategori">Laporan Menu by Kategori</a></li>
	<li><a href="?page=Laporan-Penjualan">Laporan JSS</a></li>
	<li><a href="?page=Laporan-Penjualan-Periode">Laporan JSS Per Periode</a></li>
	<li><a href="?page=Laporan-Penjualan-Menu">Laporan JSS Per Stock Code</a></li>
	<li><a href="?page=Laporan-Pembelian">Laporan Pembelian</a></li>
	<li><a href="?page=Laporan-Pembelian-Periode">Laporan Pembelian Peer Periode</a></li>
</ul>	