<?php
if(isset($_SESSION['SES_ADMIN'])) {
	echo "<style='margin:-5px 0px 5px 0px; padding:0px;'>Selamat Anda Menggunakan Software SIGAP (Sistem Informasi Gabungan DAP)";
	echo "<h2 style='margin:-5px 0px 5px 0px; padding:0px;'>The Best Support For Your Productivity!</h2>";
	echo "<b> Anda login sebagai Admin";
	exit;
}
else if(isset($_SESSION['SES_KASIR'])) {
	echo "<style='margin:-5px 0px 5px 0px; padding:0px;'>Selamat Anda Menggunakan Software SIGAP (Sistem Informasi Gabungan DAP)";
	echo "<h2 style='margin:-5px 0px 5px 0px; padding:0px;'>The Best Support For Your Productivity!</h2>";
	echo "<b> Anda login sebagai Kasir";
	include "login_info.php";
	exit;
}
else {
	echo "<h2 style='margin:-5px 0px 5px 0px; padding:0px;'>Selamat datang ........!</h2></p>";
	echo "<b>Silahkan Klik untuk Login<a href='?page=Login' alt='Login'>Job Summary Sheet </a> untuk mengakses sistem JSS</p> ";
}
?>