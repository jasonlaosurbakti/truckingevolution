<?php
include_once "library/inc.seslogin.php";

if($_GET) {
	# HAPUS DAFTAR barang DI TMP
	if(isset($_GET['Act'])){
		if(trim($_GET['Act'])=="Delete"){
			# Hapus Tmp jika datanya sudah dipindah
			$mySql = "DELETE FROM tmp_penjualan WHERE id='".$_GET['id']."' AND kd_user='".$_SESSION['SES_LOGIN']."'";
			mysql_query($mySql, $koneksidb) or die ("Gagal kosongkan tmp".mysql_error());
		}
		if(trim($_GET['Act'])=="Sucsses"){
			echo "<b>DATA BERHASIL DISIMPAN</b> <br><br>";
		}
	}
	// =========================================================================
	
	# TOMBOL PILIH (KODE barang) DIKLIK
	if(isset($_POST['btnPilih'])){
		$pesanError = array();
		if (trim($_POST['cmbMenu'])=="BLANK") {
			$pesanError[] = "<b>Nama Menu item belum diisi</b>, pilih pada daftar menu !";		
		}
		if (trim($_POST['txtJumlah'])=="" OR ! is_numeric(trim($_POST['txtJumlah']))) {
			$pesanError[] = "Data <b>Jumlah Item (Qty) belum diisi</b>, silahkan <b>isi dengan angka</b> !";		
		}
		
		# Baca variabel
		$cmbMenu	= $_POST['cmbMenu'];
		$txtJumlah	= $_POST ['txtJumlah'];
				
		# JIKA ADA PESAN ERROR DARI VALIDASI
		if (count($pesanError)>=1 ){
			echo "<div class='mssgBox'>";
			echo "<img src='images/attention.png'> <br><hr>";
				$noPesan=0;
				foreach ($pesanError as $indeks=>$pesan_tampil) { 
				$noPesan++;
					echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
				} 
			echo "</div> <br>"; 
		}
		else {
			# Jika jumlah error pesanError tidak ada			

			# Jika sudah pernah dipilih, cukup datanya di update jumlahnya			
			$cekSql ="SELECT * FROM tmp_penjualan WHERE kd_menu='$cmbMenu' AND kd_user='".$_SESSION['SES_LOGIN']."'";
			$cekQry = mysql_query($cekSql, $koneksidb) or die ("Gagal Query".mysql_error());
			if (mysql_num_rows($cekQry) >= 1) {
				// Jika tadi sudah dipilih, cukup jumlahnya diupdate
				$tmpSql = "UPDATE tmp_penjualan SET jumlah=jumlah + $txtJumlah 
							WHERE kd_menu='$cmbMenu' AND kd_user='".$_SESSION['SES_LOGIN']."'";
				mysql_query($tmpSql, $koneksidb) or die ("Gagal Query : ".mysql_error());
			}
			else {
				$menuSql ="SELECT * FROM menu WHERE kd_menu='$cmbMenu'";
				$menuQry = mysql_query($menuSql, $koneksidb) or die ("Gagal Query".mysql_error());
				$menuRow = mysql_fetch_array($menuQry);
				if (mysql_num_rows($menuQry) >= 1) {
					# Hitung Diskon (Jika Ada), dan Harga setelah diskon
					//$besarDiskon = intval($menuRow['harga']) * (intval($menuRow['diskon'])/100);
					//$hargaDiskon = intval($menuRow['harga']) - $besarDiskon;
					
					$dataHarga = $menuRow['harga'];
					$tmp2Sql = "INSERT INTO tmp_penjualan SET 
											kd_menu='$cmbMenu', 
											harga='$dataHarga', 
											jumlah='$txtJumlah', 
											kd_user='".$_SESSION['SES_LOGIN']."'";
					mysql_query($tmp2Sql, $koneksidb) or die ("Gagal Query detail barang : ".mysql_error());
				}
			}
		}

	}
	// ============================================================================
	
	# JIKA TOMBOL SIMPAN DIKLIK
	if(isset($_POST['btnSave'])){
		$pesanError = array();
		if (trim($_POST['cmbTanggal'])=="") {
			$pesanError[] = "Data <b>Tanggal transaksi</b> belum diisi, pilih pada tanggal penyelesaian !";		
		}
		$pesanError = array();
		if (trim($_POST['cmbTglOrder'])=="") {
			$pesanError[] = "Data <b>Tanggal transaksi</b> belum diisi, pilih pada tanggal Order !";
		}
		if (trim($_POST['txtNoMeja'])=="") {
			$pesanError[] = "Data <b> Location</b> belum diisi, isi dengan informasi location";		
		}
		if (trim($_POST['txtUangBayar'])==""  OR ! is_numeric(trim($_POST['txtUangBayar']))) {
			$pesanError[] = "Data <b> Finishing</b> belum diisi (Rp) !";		
		}
		if (trim($_POST['txtUangBayar']) < trim($_POST['txtTotBayar'])) {
			$pesanError[] = "Data <b> Belum di Finishing</b>";		
		}
		
		$tmpSql ="SELECT COUNT(*) As qty FROM tmp_penjualan WHERE kd_user='".$_SESSION['SES_LOGIN']."'";
		$tmpQry = mysql_query($tmpSql, $koneksidb) or die ("Gagal Query Tmp".mysql_error());
		$tmpRow = mysql_fetch_array($tmpQry);
		if ($tmpRow['qty'] < 1) {

			$pesanError[] = "<b>Item Menu</b> belum ada yang dimasukan, <b>minimal 1 menu</b>.";
		}
		
	
		# Baca variabel
		$txtNoMeja		= $_POST['txtNoMeja'];
		$txtx	        = $_POST['txtNomer'];
	    $idx	        = $_POST['txtid'];
		$txtDone		= $_POST['txtDone'];
		$txtCost		= $_POST['txtCost'];
		$txtMT			= $_POST['txtMT'];
		$txtMT2			= $_POST['txtMT2'];
		$txtHSES		= $_POST['txtHSES'];
		$txtWR			= $_POST['txtWR'];
		$txtHours		= $_POST['txtHours'];
		$txtHours2		= $_POST['txtHours2'];
		$txtHours3		= $_POST['txtHours3'];
		$txtHours4		= $_POST['txtHours4'];
		$txtHours5		= $_POST['txtHours5'];
		$tjam            =$txtHours+$txtHours2+$txtHours3+$txtHours4+$txtHours5;
		$txtTrade		= $_POST['txtTrade'];
		$txtTrade2		= $_POST['txtTrade2'];
		$txtTrade3		= $_POST['txtTrade3'];
		$txtTrade4		= $_POST['txtTrade4'];
		$txtTrade5		= $_POST['txtTrade5'];	
		$txtKaryawan	= $_POST['txtKaryawan'];
		$txtKaryawan2	= $_POST['txtKaryawan2'];
		$txtKaryawan3	= $_POST['txtKaryawan3'];
		$txtKaryawan4	= $_POST['txtKaryawan4'];
		$txtKaryawan5	= $_POST['txtKaryawan5'];
		$txtPelanggan	= $_POST['txtPelanggan'];
		$txtKeterangan	= $_POST['txtKeterangan'];
		$txtUangBayar	= $_POST['txtUangBayar'];
		$cmbTanggal 	= $_POST['cmbTanggal'];
		$cmbTglOrder	= $_POST['cmbTglOrder'];
		$cmbTglPri	= $_POST['cmbTglPri'];
		$cmbTglSinggih	= $_POST['cmbTglSinggih'];
		$cmbTglOny	= $_POST['cmbTglOny'];
				
				
				
		# JIKA ADA PESAN ERROR DARI VALIDASI
		if (count($pesanError)>=1 ){
			echo "<div class='mssgBox'>";
			echo "<img src='images/attention.png'> <br><hr>";
				$noPesan=0;
				foreach ($pesanError as $indeks=>$pesan_tampil) { 
				$noPesan++;
					echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
				} 
			echo "</div> <br>"; 
		}
		else {
			# SIMPAN DATA KE DATABASE
			# Jika jumlah error pesanError tidak ada
			 $t=date("d");
				$tg=date("m/Y");
				$tmpSql2 ="SELECT * FROM penjualan WHERE kd_user='".$_SESSION['SES_LOGIN']."' order by id desc";
				$tmpQry2 = mysql_query($tmpSql2, $koneksidb) or die ("Gagal Query Tmp".mysql_error());
				$tmpRow2 = mysql_fetch_array($tmpQry2);
				$ids=$tmpRow2['id'];
				$nop=$tmpRow2['no_penjualan'];
				$go=1;
				if($t==1){
					$ih="DAP0$ids/$tg";
				                        if($nop=$ih){
											 $ida=$ids+$go;
				                             $dg="DAP0$ida/$tg";
										}else{
											$ida=$go;
				                            $dg="DAP0$ida/$tg";	
				
				                              }
				
					}else{
				$ida=$ids+$go;
				$dg="DAP0$ida/$tg";
				}
			$noTransaksi = $dg;
			$mySql	= "INSERT INTO penjualan SET 
							no_penjualan='$noTransaksi', 
							tgl_penjualan='".InggrisTgl($_POST['cmbTanggal'])."',  
							tgl_order='".InggrisTgl($_POST['cmbTglOrder'])."',
							tgl_pri='".InggrisTgl($_POST['cmbTglPri'])."',
							tgl_singgih='".InggrisTgl($_POST['cmbTglSinggih'])."',
							tgl_ony='".InggrisTgl($_POST['cmbTglOny'])."',
							nomor_meja='$txtNoMeja', 
							mt='$txtMT',
							mt2='$txtMT2',
							hses='$txtHSES',
							cost='$txtCost',
							done='$txtDone',
							id='$idx',
							workrequest='$txtWR',
							hours='$txtHours',
							hours2='$txtHours2',
							hours3='$txtHours3',
							hours4='$txtHours4',
							hours5='$txtHours5',
							trade='$txtTrade',
							trade2='$txtTrade2',
							trade3='$txtTrade3',
							trade4='$txtTrade4',
							trade5='$txtTrade5',
							totjam='$tjam',
							karyawan='$txtKaryawan',
							karyawan2='$txtKaryawan2',
							karyawan3='$txtKaryawan3',
							karyawan4='$txtKaryawan4',
							karyawan5='$txtKaryawan5',
							pelanggan='$txtPelanggan', 
							keterangan='$txtKeterangan',
							uang_bayar='$txtUangBayar',
							kd_user='".$_SESSION['SES_LOGIN']."'";
			$myQry=mysql_query($mySql, $koneksidb) or die ("Gagal query".mysql_error());
			
			if($myQry){
				# �LANJUTAN, SIMPAN DATA
				# Ambil semua data barang yang dipilih, berdasarkan kasir yg login
				$tmpSql ="SELECT * FROM tmp_penjualan WHERE kd_user='".$_SESSION['SES_LOGIN']."'";
				$tmpQry = mysql_query($tmpSql, $koneksidb) or die ("Gagal Query Tmp".mysql_error());
				while ($tmpRow = mysql_fetch_array($tmpQry)) {
					$dataKode =	$tmpRow['kd_menu'];
					$dataHarga=	$tmpRow['harga'];
					$dataJumlah=$tmpRow['jumlah'];
					
					// Masukkan semua data dari tabel TMP ke tabel ITEM
					$itemSql = "INSERT INTO penjualan_item SET 
											no_penjualan='$noTransaksi', 
											kd_menu='$dataKode', 
											harga='$dataHarga', 
											jumlah='$dataJumlah'";
		  			mysql_query($itemSql, $koneksidb) or die ("Gagal Query ".mysql_error());
					
					// Skrip Update stok
					//$stokSql = "UPDATE barang SET stok = stok - $tmpRow[jumlah] WHERE kd_barang='$tmpRow[kd_barang]'";
		  			//mysql_query($stokSql, $koneksidb) or die ("Gagal Query Edit Stok".mysql_error());
				}
				
				# Kosongkan Tmp jika datanya sudah dipindah
				$hapusSql = "DELETE FROM tmp_penjualan WHERE kd_user='".$_SESSION['SES_LOGIN']."'";
				mysql_query($hapusSql, $koneksidb) or die ("Gagal kosongkan tmp".mysql_error());
				
				// Refresh form
				echo "<meta http-equiv='refresh' content='0; url=transaksi_penjualan_view.php?noNota=$noTransaksi'>";
			}
			else{
				$pesanError[] = "Gagal penyimpanan ke database";
			}
		}	
	}
	
	// ============================================================================
} // Penutup GET

# TAMPILKAN DATA KE FORM
$noTransaksi 	= buatKode("penjualan", "DAP");
$tglTransaksi 	= isset($_POST['cmbTanggal']) ? $_POST['cmbTanggal'] : date('d-m-Y');
$tglOrder 		= isset($_POST['cmbTglOrder']) ? $_POST['cmbTglOrder'] : date('d-m-Y');
$tglPri 		= isset($_POST['cmbTglPri']) ? $_POST['cmbTglPri'] : date('d-m-Y');
$tglSinggih 		= isset($_POST['cmbTglSinggih']) ? $_POST['cmbTglSinggih'] : date('d-m-Y');
$tglOny 		= isset($_POST['cmbTglOny']) ? $_POST['cmbTglOny'] : date('d-m-Y');
$dataNoMeja		= isset($_POST['txtNoMeja']) ? $_POST['txtNoMeja'] : '';
$dataKaryawan	= isset($_POST['txtKaryawan']) ? $_POST['txtKaryawan'] : '';
$dataKaryawan2	= isset($_POST['txtKaryawan2']) ? $_POST['txtKaryawan2'] : '';
$dataKaryawan3	= isset($_POST['txtKaryawan3']) ? $_POST['txtKaryawan3'] : '';
$dataKaryawan4	= isset($_POST['txtKaryawan4']) ? $_POST['txtKaryawan4'] : '';
$dataKaryawan5	= isset($_POST['txtKaryawan5']) ? $_POST['txtKaryawan5'] : '';
$dataCost		= isset($_POST['txtCost']) ? $_POST['txtCost'] : '';
$dataDone		= isset($_POST['txtDone']) ? $_POST['txtDone'] : '';
$dataWR			= isset($_POST['txtWR'])? $_POST['txtWR'] : '';
$dataHours		= isset($_POST['txtHours']) ? $_POST['txtHours'] : '00';
$dataHours2		= isset($_POST['txtHours2']) ? $_POST['txtHours2'] : '00';
$dataHours3		= isset($_POST['txtHours3']) ? $_POST['txtHours3'] : '00';
$dataHours4		= isset($_POST['txtHours4']) ? $_POST['txtHours4'] : '00';
$dataHours5		= isset($_POST['txtHours5']) ? $_POST['txtHours5'] : '00';
$dataTrade		= isset($_POST['txtTrade']) ? $_POST['txtTrade'] : '';
$dataTrade2		= isset($_POST['txtTrade2']) ? $_POST['txtTrade2'] : '';
$dataTrade3		= isset($_POST['txtTrade3']) ? $_POST['txtTrade3'] : '';
$dataTrade4		= isset($_POST['txtTrade4']) ? $_POST['txtTrade4'] : '';
$dataTrade5		= isset($_POST['txtTrade5']) ? $_POST['txtTrade5'] : '';
$dataMT			= isset($_POST['txtMT']) ? $_POST['txtMT'] : '';
$dataMT2		= isset($_POST['txtMT2']) ? $_POST['txtMT2'] : '';
$dataHSES		= isset($_POST['txtHSES']) ? $_POST['txtHSES'] : '';
$dataPelanggan	= isset($_POST['txtPelanggan']) ? $_POST['txtPelanggan'] : '';
$dataKeterangan	= isset($_POST['txtKeterangan']) ? $_POST['txtKeterangan'] : '';
$dataUangBayar	= isset($_POST['txtUangBayar']) ? $_POST['txtUangBayar'] : '';
?>
<form action="?page=Transaksi-Penjualan" method="post"  name="frmadd">
  <table width="808" cellpadding="3" cellspacing="1" class="table-common" style="margin-top:0px;">
  <tr>
    <td width="798" height="460"><table width="821" cellpadding="3" cellspacing="1" class="table-common" style="margin-top:0px;">
      <tr></tr>
      <tr>
        <td width="811" height="443"><table width="840" cellpadding="3" cellspacing="1" class="table-common" style="margin-top:0px;">
          <tr>
            <td colspan="2" align="left"><h4><b>DAILY WORK SHEET</b></h4></td>
            <td colspan="3" align="left"><input name="btnSave" type="submit" style="cursor:pointer;" value=" SIMPAN TRANSAKSI " /></td>
            <?php
			
			$t=date("d");
			$tg=date("m/Y");
				$tmpSql2 ="SELECT * FROM penjualan WHERE kd_user='".$_SESSION['SES_LOGIN']."' order by id desc";
				$tmpQry2 = mysql_query($tmpSql2, $koneksidb) or die ("Gagal Query Tmp".mysql_error());
				$tmpRow2 = mysql_fetch_array($tmpQry2);
				$ids=$tmpRow2['id'];
				$go=1;
				if($t==1){
					 	$ih="DAP0$ids/$tg";
				                      if($nop=$ih){
											 $ida=$ids+$go;
				                             $dg="DAP0$ida/$tg";
										}else{
											$ida=$go;
				                            $dg="DAP0$ida/$tg";	
				
				                              }
				
					}else{
				$ida=$ids+$go;
				$dg="DAP0$ida/$tg";
				}
			?>
            
          </tr>
          <tr>
            <td width="11%"><b>Job Alocation No</b></td>
            <td width="6%"><b>:</b></td>
            <td colspan="3"><input name="txtNomor" value='DAP0<?php echo"$ida/$tg";?>' size="11" maxlength="11"/>
              <b>
              <input name="txtid" value='<?php echo"$ida";?>' size="11" maxlength="11"hidden="hidden" />
              Work Request No.:
                <input name="txtWR" value="<?php echo $dataWR; ?>" size="10" maxlength="20" />
              </b></td>
          </tr>
          <tr>
            <td width="11%"><b>Performance</b></td>
            <td width="6%"><b>:</b></td>
            <td width="10%">Q              
              <input name="txtMT" id="txtMT" 
      		 	 onfocus="if (value == 'Good') {value ='Good'}" 
	  			 onblur="if (value == 'Good') {value = 'Good'}" value="<?php echo $dataMT; ?>" size="4" maxlength="4"/></td>
            <td width="16%">M.Time
              <input name="txtMT2" id="txtMT2" 
      		 	 onfocus="if (value == 'Good') {value ='Good'}" 
	  			 onblur="if (value == 'Good') {value = 'Good'}" value="<?php echo $dataMT2; ?>" size="4" maxlength="4"/></td>
            <td width="56%">HSES
              <input name="txtHSES" id="txtHSES" 
      		 	 onfocus="if (value == 'Good') {value =''}" 
	  			 onblur="if (value == 'Good') {value = 'Good'}" value="<?php echo $dataHSES; ?>" size="4" maxlength="4"/></td>
          </tr>
          <tr>
            <td><b>Finish Date</b></td>
            <td><b>:</b></td>
            <td colspan="3"><?php echo form_tanggal("cmbTanggal",$tglTransaksi); ?> <b>Order Date. <?php echo form_tanggal("cmbTglOrder",$tglOrder); ?></b></td>
          </tr>
          <tr>
            <td><b>Location</b></td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtNoMeja" id="txtNoMeja" 
      		 	 onfocus="if (value == '') {value =''}" 
	  			 onblur="if (value == '') {value = ''}" value="<?php echo $dataNoMeja; ?>" size="30" maxlength="30"/>
              <b>User:
                <input name="txtPelanggan" id="txtPelanggan" 
      		 	 onfocus="if (value == '') {value =''}" 
	  			 onblur="if (value == '') {value = ''}" value="<?php echo $dataPelanggan; ?>" size="20" maxlength="20"/>
                * Diisi nama pemesan</b></td>
          </tr>
          <tr>
            <td><b>Man Power</b></td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtKaryawan" value="<?php echo $dataKaryawan; ?>" size="30" maxlength="60" />
              Work Hour
              <input name="txtHours" value="<?php echo $dataHours; ?>" size="4" maxlength="4" />
              Trade
              <input name="txtTrade" value="<?php echo $dataTrade; ?>" size="10" maxlength="10" />
              1</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtKaryawan2" value="<?php echo $dataKaryawan2; ?>" size="30" maxlength="60" />
              Work Hour
              <input name="txtHours2" value="<?php echo $dataHours2; ?>" size="4" maxlength="4" />
              Trade
              <input name="txtTrade2" value="<?php echo $dataTrade2; ?>" size="10" maxlength="10" />
              2</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtKaryawan3" value="<?php echo $dataKaryawan3; ?>" size="30" maxlength="60" />
              Work Hour
              <input name="txtHours3" value="<?php echo $dataHours3; ?>" size="4" maxlength="4" />
              Trade
              <input name="txtTrade3" value="<?php echo $dataTrade3; ?>" size="10" maxlength="10" />
              3</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtKaryawan4" value="<?php echo $dataKaryawan4; ?>" size="30" maxlength="60" />
              Work Hour
              <input name="txtHours4" value="<?php echo $dataHours4; ?>" size="4" maxlength="4" />
              Trade
              <input name="txtTrade4" value="<?php echo $dataTrade4; ?>" size="10" maxlength="10" />
              4</td>
          </tr>
          <tr>
            <td></td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtKaryawan5" value="<?php echo $dataKaryawan5; ?>" size="30" maxlength="60" />
              Work Hour
              <input name="txtHours5" value="<?php echo $dataHours5; ?>" size="4" maxlength="4" />
              Trade
              <input name="txtTrade5" value="<?php echo $dataTrade5; ?>" size="10" maxlength="10" />
              5</td>
          </tr>
          <tr>
            <td><strong>Keterangan</strong></td>
            <td><b>:</b></td>
            <td colspan="3"><input name="txtKeterangan" value="<?php echo $dataKeterangan; ?>" size="55" maxlength="100" />
              <strong>Cost Center:</strong><b>
                <input name="txtCost" value="<?php echo $dataCost; ?>" size="20" maxlength="100" />
              </b></td>
          </tr>
          <tr>
            <td><strong>Actual Work Done</strong></td>
            <td><b>:</b></td>
            <td colspan="3" rowspan="2"><textarea name="txtDone" cols="80" rows="2"><?php echo $dataDone; ?></textarea></td>
          </tr>
          <tr>
            <td><b></b></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><b>Description</b></td>
            <td><b>:</b></td>
            <td colspan="3"><b>
              <div id="formbarang">

  <div class="demo" ">
  <div><input type="text" name="cmbMenu" id="barang"style=" 
    padding: 6px 20px;
   
    font-size: 13px;
    margin: 4px 2px;
    "placeholder="Masukan kode Desc..">
    Jumlah
    <input class="text" name="txtJumlah" size="6" maxlength="10" value="1" 
	  		 onblur="if (value == '') {value = ''}" 
      		 onfocus="if (value == '') {value =''}"/>
    <input name="btnPilih" type="submit" style="  background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 12px 28px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;" value="PILIH" />
  </div>
  </div> 
  </div></td> <td>
    <p align=right></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  </table>
  <table class="table-list" width="862" border="0" cellspacing="1" cellpadding="2">
 
  <tr>
    <td width="22" align="center" bgcolor="#CCCCCC"><b>No</b></td>
    <td width="68" align="center" bgcolor="#CCCCCC"><b>Kode</b></td>
    <td width="329" bgcolor="#CCCCCC"><b>Description</b></td>
  
    <td width="70" align="right" bgcolor="#CCCCCC"><b>Qty</b></td>
    <td width="72" align="center" bgcolor="#CCCCCC"><b>Unit</b></td>
    <td width="102" align="center" bgcolor="#CCCCCC"><b>Harga (Rp.)</b></td>
    <td width="99" align="right" bgcolor="#CCCCCC"><b>Subtotal (Rp.) </b></td>
    <td width="59" align="center" bgcolor="#FFCC00"><b>Delete</b></td>
   
    </tr>
<?php
//  tabel menu 
$tmpSql ="SELECT menu.*, tmp_penjualan.id, tmp_penjualan.jumlah 
		FROM menu, tmp_penjualan
		WHERE menu.kd_menu=tmp_penjualan.kd_menu 
		AND tmp_penjualan.kd_user='".$_SESSION['SES_LOGIN']."'
		ORDER BY tmp_penjualan.id asc ";
$tmpQry = mysql_query($tmpSql, $koneksidb) or die ("Gagal Query Tmp".mysql_error());
$totalBayar = 0; $qtyItem =00.00; $nomor=0;
while($tmpRow = mysql_fetch_array($tmpQry)) {
	$nomor++;
	$id			= $tmpRow['id'];
	$subSotal 	= $tmpRow['jumlah'] * $tmpRow['harga'];
	$totalBayar	= $totalBayar + $subSotal;
	$qtyItem	= $qtyItem + $tmpRow['jumlah'];
?>
  <tr>
    <td align="center"><?php echo $nomor; ?></td>
    <td align="center"><b><?php echo $tmpRow['kd_menu']; ?></b></td>
    <td><?php echo $tmpRow['nm_menu']; ?></td>
    <td align="right"><?php echo format_angka($tmpRow['jumlah']); ?></td>
     <td align="left"><?php echo $tmpRow['nm_menu2']; ?></td>
    <td align="center"><?php echo format_angka($tmpRow['harga']); ?></td>
    <td align="right"><?php echo format_angka($subSotal); ?></td>
    <td align="center" bgcolor="#FFFFCC"><a href="?page=Transaksi-Penjualan&Act=Delete&id=<?php echo $id; ?>" target="_self"><img src="images/hapus.gif" width="16" height="16" border="0" /></a></td>
    </tr>
<?php 
}?>
  <tr>   <td align="right"colspan=4 bgcolor="#F5F5F5"><b><?php echo $qtyItem; ?></b></td>
    <td colspan="2" align="right" bgcolor="#F5F5F5"><b>Total Bayar (Rp.) :</b></td>
 
    <td align="right" bgcolor="#F5F5F5"><b><?php echo format_angka($totalBayar); ?></b></td>
    <td align="center" bgcolor="#F5F5F5">&nbsp;</td>
    </tr>
  <tr>
    <td colspan="6" align="right" bgcolor="#F5F5F5"><b>Finishing (Rp.) :</b></td>
    
    <td align="left" bgcolor="#F5F5F5"><input name="txtUangBayar" value="<?php echo $dataUangBayar; ?>" size="16" maxlength="12"/></td>
    <td align="center" bgcolor="#F5F5F5"><input name="txtTotBayar" type="hidden" value="<?php echo $totalBayar; ?>" /></td>
    </tr>
  </table>
</form>
