<?php
if(isset($_SESSION['SES_ADMIN'])){
# JIKA YANG LOGIN LEVEL ADMIN, menu di bawah yang dijalankan
?>
<ul>
	<li><a href='?page' title='Halaman Utama'>Home</a></li>
	<li><a href='?page=User-Data' title='User Login'>Data User (Kasir)</a></li>
	<li><a href='?page=Supplier-Data' title='Supplier'>Data Supplier</a></li>
	<li><a href='?page=Kategori-Data' title='Data Kategori'>Data Kategori Pekerjaan</a></li>
    <li><a href='?page=Menu-Data' title='Menu'>Code Stock</a></li>
	<li><a href='?page=Pemesanan-Add' title='Pemesanan'>Work Order</a></li>
	<li><a href='?page=Transaksi-Penjualan' title='Transaksi Penjualan' target='_blank'>Input Daily Work Sheet</a></li>
	<li><a href='?page=Transaksi-Pembelian' title='Transaksi Pembelian' target='_blank'>Input Pembelian</a> </li>
	<li><a href='?page=Laporan' title='Laporan'>Laporan</a></li>
	<li><a href='?page=Logout' title='Logout (Exit)'>Logout</a></li>
</ul>
<?php
}
elseif(isset($_SESSION['SES_KASIR'])){
# JIKA YANG LOGIN LEVEL KASIR, menu di bawah yang dijalankan
?>
<ul>
	<li><a href='?page' title='Halaman Utama'>Home</a></li>
	<li><a href='?page=Pemesanan-Add' title='Pemesanan'>Work Order</a></li>
		<li><a href='?page=Kategori-Man-Data' title='Man Power'target='_blank'>Input Daily Work Sheet</a></li>
	<li><a href='?page=Transaksi-Penjualan' title='Transaksi Penjualan' target='_blank'>Input Daily Work Sheet</a></li>
	<li><a href='?page=Transaksi-Pembelian' title='Transaksi Pembelian' target='_blank'>Input Pembelian</a></li>
	
	<li><a href='?page=Logout' title='Logout (Exit)'>Logout</a></li>
</ul>
<?php
}
else {
# JIKA BELUM LOGIN (BELUM ADA SESION LEVEL YG DIBACA)
?>
<ul>
	<li><a href='?page=Login' title='Login System'>Login</a></li>	
</ul>
<?php
}
?>