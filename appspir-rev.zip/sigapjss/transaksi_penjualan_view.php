<?php
include_once "library/inc.connection.php";
include_once "library/inc.library.php";

# Baca variabel URL
$kodeTransaksi = $_GET['noNota'];

# Perintah untuk mendapatkan data dari tabel penjualan
$mySql = "SELECT penjualan.*, user.nm_user FROM penjualan, user 
			WHERE penjualan.kd_user=user.kd_user AND no_penjualan='$kodeTransaksi'";
$myQry = mysql_query($mySql, $koneksidb)  or die ("Query penjualan salah : ".mysql_error());
$kolomData = mysql_fetch_array($myQry);




?>

<html>
<head>
<title> :: DAILY WORK SHEET</title>
<link href="styles/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="754" border="0" cellspacing="1" cellpadding="4" class="table-print">
  <tr>
    <td width="125" rowspan="3" align="center"><img src="images/logo_kecil.png" width="66" height="46" /></td>
    <td colspan="2" align="center"><b>PT DAVINDO ADI PRATAMA    </b></h3>
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center"><div align="center"><b>ELECTRIC MAINTENANCE
      <br>JOB SHEET SUMMARY</b></br>
    </div></td>
  </tr>
  <tr>
    <td colspan="2" align="center" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td align="left">Job Alocation No </td>
    <td width="315">:<?php echo $kolomData['no_penjualan']; ?></td>
    <td width="left" valign="top">Cost Center</td><td width="141"><?php echo $kolomData['cost']; ?></td>
  </tr>
  <tr>

    <td align="left">Work Order </td>
    <td>:</td>
    <td valign="top">Order Date</td><td><?php echo $kolomData['tgl_order']; ?></td>
  </tr>
  <tr>
    <td align="left">Work Request</td>
    <td>:<?php echo $kolomData['workrequest']; ?></td>
    <td valign="top">Completion Date</td><td><?php echo $kolomData['tgl_penjualan']; ?></td>
  </tr>
  <tr>
    <td align="left">Location</td>
    <td>:<?php echo $kolomData ['nomor_meja']; ?> </td>
    <td valign="top">Originator</td>
    <td>Onny B Andalas</td>
  </tr>
  <tr>
    <td align="left">Description</td>
    <td>:<?php echo $kolomData ['keterangan']; ?></td>
    <td valign="top">Est Cost IDR</td><td><b><?php echo format_angka($kolomData['uang_bayar']); ?></b></td>
  </tr>
  <tr>
    <td align="left">&nbsp;</td>
    <td align="left" colspan="3" rowspan="3">:<?php echo $kolomData ['done']; ?></td>
  </tr>
  <tr>
    <td align="left"><b>Actual Well Done </b></td>
  </tr>
  <tr>
    <td align="left">&nbsp;</td>
  </tr>
</table>

<tr>Man Power Used :</tr>
<table width="753" height="180" border="0" cellpadding="2" cellspacing="1" class="table-list">
  
  <tr>
    <td width="315" bgcolor="#CCCCCC"><strong>Name</strong></td>
    <td width="97" bgcolor="#CCCCCC"><strong>Date </strong></td>
    <td width="157" bgcolor="#CCCCCC"><strong>Trade</strong></td>
    <td width="56" bgcolor="#CCCCCC"><strong>Hours</strong></td>
    <td align="right" width="93" height="22" colspan="5" bgcolor="#CCCCCC"><strong>Total Price</strong></td>
  <tr>
    <td><?php echo $kolomData ['karyawan']; ?></td>
    <td><?php echo $kolomData['tgl_penjualan']; ?></td>
    <td><?php echo $kolomData['trade']; ?></td>
    <td><?php echo $kolomData ['hours']; ?></td>
  <td align="right"><?php echo $kolomData ['hours']; ?>.00</td>	
    <td height="22" colspan="5">&nbsp;</td>
  <tr>
    <td><?php echo $kolomData ['karyawan2']; ?></td>
    <td>&nbsp;</td>
    <td><?php echo $kolomData['trade2']; ?></td>
       <td><?php echo $kolomData ['hours2']; ?></td>
	  <td align="right"><?php echo $kolomData ['hours2']; ?>.00</td>
    <td height="22" colspan="5">&nbsp;</td>
  <tr>
    <td><?php echo $kolomData ['karyawan3']; ?></td>
    <td>&nbsp;</td>
    <td><?php echo $kolomData['trade3']; ?></td>
      <td><?php echo $kolomData ['hours3']; ?></td>
	  <td align="right"><?php echo $kolomData ['hours3']; ?>.00</td>
    <td height="22" colspan="5">&nbsp;</td>
  <tr>
    <td><?php echo $kolomData ['karyawan4']; ?></td>
    <td>&nbsp;</td>
    <td><?php echo $kolomData['trade4']; ?></td>
      <td><?php echo $kolomData ['hours4']; ?></td>
	  <td align="right"><?php echo $kolomData ['hours4']; ?>.00</td>
    <td height="22" colspan="5">&nbsp;</td>
  <tr>
    <td><?php echo $kolomData ['karyawan5']; ?></td>
    <td>&nbsp;</td>
    <td><?php echo $kolomData['trade5']; ?></td>
     <td><?php echo $kolomData ['hours5']; ?></td>
	  <td align="right"><?php echo $kolomData ['hours5']; ?>.00</td>
    <td height="22" colspan="5">&nbsp;</td>
  <tr>
	 <td height="25" colspan=4 align="right" bgcolor="#fff"><b>TOTAL</b></td>
   <td align="right" width=75 bgcolor="#F5F5F5"><b><?php echo format_angka($kolomData['totjam']); ?>.00</b></td>
  </tr>
    
</table>
<table width="754" height="126" border="0" cellpadding="2" cellspacing="1" class="table-list">
  <tr>
    <td height="23" colspan="7">Part Used</td>
     </tr>
     
  <tr>
  
    <td width="28" height="22" align="center" bgcolor="#CCCCCC"><b>No</b></td>
    <td width="116" align="center" bgcolor="#CCCCCC"><strong>KPC Stock Code</strong></td>
    <td  width="320" bgcolor="#CCCCCC" align=center><b>Description</b></td>
	<td width="82" bgcolor="#CCCCCC" align=center><p><b>Harga</b> <b> (Rp)</b></p></td>
  
    <td width="48" align="right" bgcolor="#CCCCCC"><strong>Jumlah</strong></td>
    <td width="42" align="center" bgcolor="#CCCCCC"><b>Unit</b></td>
    <td width="82" align="right" bgcolor="#CCCCCC"><b>Subtotal (Rp)</b></td>
  </tr>
	<?php
		# Menampilkan List Item menu yang dibeli untuk Nomor Transaksi Terpilih
		$notaSql = "SELECT menu.*, penjualan_item.*,penjualan_item.id FROM menu, penjualan_item
					WHERE menu.kd_menu=penjualan_item.kd_menu AND penjualan_item.no_penjualan='$kodeTransaksi'
					ORDER BY penjualan_item.id desc";
		$notaQry = mysql_query($notaSql, $koneksidb)  or die ("Query list menu salah : ".mysql_error());
		$nomor  = 0;  $totalBelanja = 0;
		while ($notaRow = mysql_fetch_array($notaQry)) {
		$nomor++;
		# Hitung Diskon (jika ada), dan Harga setelah diskon
		//$besarDiskon = intval($notaRow['harga']) * (intval($notaRow['diskon'])/100);
		//$hargaDiskon = intval($notaRow['harga']) - $besarDiskon;
		
		# Membuat Subtotal
		$subtotal  = $notaRow['harga'] * intval($notaRow['jumlah']); 
		
		# Menghitung Total Belanja keseluruhan
		$totalBelanja = $totalBelanja + intval($subtotal);
		
		# Hitung sisa bayar (pengembalian)
		$UangKembali = $kolomData['uang_bayar'] - $totalBelanja;
	?>
  <tr>
    <td height="25" align="center"><?php echo $nomor; ?></td>
    <td align="center"><?php echo $notaRow['kd_menu'];?></td>
    <td><?php echo $notaRow['nm_menu']; ?></td>
	 <td align="right"><?php echo format_angka($notaRow['harga']); ?></td>
    
    <td align="right"><?php echo $notaRow['jumlah']; ?></td>
    <td align="center"><?php echo $notaRow['nm_menu2']; ?></td>
    <td align="right"><?php echo format_angka($subtotal); ?></td>
  </tr>
  <?php } ?>
  <tr>
    <td height="25" colspan="6" align="right"><b>Sub Total (Rp) : </b></td>
    <td align="right" bgcolor="#F5F5F5"><b><?php echo format_angka($totalBelanja); ?></b></td>
  </tr>
  <tr>
    <td colspan="6" align="right"><strong>GRAND TOTAL</strong></td>
    <td align="right" bgcolor="#CCCCCC"><b><?php echo format_angka($kolomData['uang_bayar']); ?></b></td>
  </tr>
</table>
<table width="752" height="62" border="0" cellpadding="1" cellspacing="0" class="table-print">
  <tr>
    <td width="246" height="62" align="center" valign="top"><p><strong>Sign <br />
      PT. DAVINDO ADI PRATAMA</strong></p>
      <p>&nbsp;</p>
      <b>Priatno <br>
      Z86586 </b>
      <br>
      Date.............</br></td>
    <td width="283" align="center" valign="top"><p><b>Sign <br />
      PT. DAVINDO ADI PRATAMA</b></p>
      <p>&nbsp;</p>
      <p><b>Singgih Wibawanto <br>
        Z86585</b>
        <br>
        Date...................</p></td>
    <td width="217" align="center" valign="top"><p><b>Approved by<br />
      PT. KALTIM PRIMA COAL</b></p>
      <p>&nbsp;</p>
     <b>Onny B. Andalas<br>
        16752</b><br>
        Date..................</br></td>
  </tr>
</table>

<img src="images/btn_print.png" width="30" height="32" onClick="javascript:window.print()" />
</body>
</html>