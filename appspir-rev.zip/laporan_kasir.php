<ul>
	<li><a href="?page=Laporan-Kategori">DATA KATEGORI</a></li>
	<li><a href="?page=Laporan-Menu-kasir">DAFTAR BARANG/MATERIAL</a></li>
	<li><a href="?page=Laporan-Penjualan-kasir">REPORT TRUCKING </a></li>
	<li><a href="?page=Laporan-Penjualan-Menu">PENGGUNAAN MATERIAL</a></li>	
</ul>	