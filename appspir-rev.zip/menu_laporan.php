<ul>
	<li><a href="?page=Laporan-Kategori">Data Kategori</a></li>
	<li><a href="?page=Laporan-Menu">Data Stock Code</a></li>
	<li><a href="?page=Laporan-Penjualan-Periode">Report Trucking Per Periode</a></li>
	<li><a href="?page=Laporan-Penjualan">Report Trucking</a></li>
	<li><a href="?page=Laporan-Pembelian">Report P2H</a></li>
	<li><a href="?page=Laporan-Penjualan-Menu">Report Trucking Penggunaan Item</a></li></ul>
