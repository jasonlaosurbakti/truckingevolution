<?php
include_once "config.php";
$q = $_GET["q"];
if (!$q) return;

$sql = "select * from menu where nm_menu LIKE '%$q%'";
$rsd = mysql_query($sql);
while($rs = mysql_fetch_array($rsd)) {
	$cnames = $rs['nm_menu'];
	$kdmenu = $rs['kd_menu'];
	echo "$cnames\n";
}
?>
Data tidak ditemukan ! 