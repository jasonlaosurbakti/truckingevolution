<?php
# Konek ke Web Server Lokal
$myHost	= "localhost";
$myUser	= "root";
$myPass	= "";
$myDbs	= "sigap";

# Konek ke Web Server Lokal
$koneksidb= mysql_connect($myHost, $myUser, $myPass);


# Memilih database pd MySQL Server
@mysql_select_db($myDbs) or die ("Database not Found !");
?>